from django.contrib import admin

# Register your models here.

from .models import Book, Borrow, Student, IssuedBook

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'genre', 'available')
    list_filter = ('genre', 'available')
    search_fields = ('title', 'author')

@admin.register(Borrow)
class BorrowAdmin(admin.ModelAdmin):
    list_display = ('book', 'user', 'borrow_date', 'return_date', 'actual_return_date', 'overdue')
    list_filter = ('book', 'user', 'overdue')

admin.site.register(Student)
admin.site.register(IssuedBook)
