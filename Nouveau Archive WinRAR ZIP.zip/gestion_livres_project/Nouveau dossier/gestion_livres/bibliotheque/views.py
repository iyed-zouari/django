from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Borrow, Book,IssuedBook,Student
from datetime import timedelta, date
from django.db.models import Q
from django.contrib.auth import authenticate, login, logout
from .forms import BookForm, IssueBookForm 

# Liste des livres disponibles
def book_list(request):
    books = Book.objects.all()
    return render(request, 'bibliotheque/book_list.html', {'books': books})

# Emprunter un livre
@login_required
def borrow_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if not book.available:
        return redirect('book_list')
    Borrow.objects.create(
        book=book,
        user=request.user,
        return_date=date.today() + timedelta(days=14)
    )
    book.available = False
    book.save()
    return redirect('book_list')

# Retourner un livre emprunté
@login_required
def return_book(request, borrow_id):
    borrow = get_object_or_404(Borrow, id=borrow_id, user=request.user)
    borrow.actual_return_date = date.today()
    borrow.book.available = True
    borrow.book.save()
    borrow.save()
    return redirect('borrow_history')

# Historique des emprunts
@login_required
def borrow_history(request):
    borrows = Borrow.objects.filter(user=request.user)
    return render(request, 'bibliotheque/borrow_history.html', {'borrows': borrows})

# Recherche de livres
def search_books(request):
    query = request.GET.get('q', '')
    books = Book.objects.filter(Q(title__icontains=query) | Q(author__icontains=query))
    return render(request, 'bibliotheque/search_results.html', {'books': books, 'query': query})

# Connexion de l'utilisateur
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Redirection vers la page d'accueil
        else:
            error_message = "Nom d'utilisateur ou mot de passe incorrect."
            return render(request, 'bibliotheque/login.html', {'error_message': error_message})
    return render(request, 'bibliotheque/login.html')

# Page d'accueil
@login_required
def home_view(request):
    return render(request, 'bibliotheque/home.html')

# Déconnexion
def logout_view(request):
    logout(request)
    return redirect('login')

# Ajouter un livre
def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_books')  # Redirige vers la page des livres disponibles
    else:
        form = BookForm()
    return render(request, 'bibliotheque/add_book.html', {'form': form})

# Voir les livres disponibles
def view_books(request):
    books = Book.objects.all()  # Récupère tous les livres disponibles
    return render(request, 'bibliotheque/view_books.html', {'books': books})

# Emprunter un livre
def issue_book(request):
    if request.method == 'POST':
        form = IssueBookForm(request.POST)
        if form.is_valid():
            book_id = form.cleaned_data['book']
            student_id = form.cleaned_data['student']
            book = Book.objects.get(id=book_id)
            student = Student.objects.get(id=student_id)

            # Logique d'emprunt : marquer le livre comme emprunté
            IssuedBook.objects.create(book=book, student=student)
            book.is_issued = True  # Mettre à jour l'état du livre
            book.save()
            return redirect('view_issued_books')  # Redirige vers les livres empruntés
    else:
        form = IssueBookForm()
    return render(request, 'bibliotheque/issue_book.html', {'form': form})

# Voir les livres empruntés
def view_issued_books(request):
    issued_books = IssuedBook.objects.all()  # Récupère tous les livres empruntés
    return render(request, 'bibliotheque/view_issued_books.html', {'issued_books': issued_books})

# Voir les étudiants
def view_students(request):
    students = Student.objects.all()  # Récupère tous les étudiants
    return render(request, 'bibliotheque/view_students.html', {'students': students})