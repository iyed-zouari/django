from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('login/', views.login_view, name='login'),
    path('home/', views.home_view, name='home'),
    path('book_list/', views.book_list, name='book_list'),
    path('search/', views.search_books, name='search_books'),
    path('logout/', views.logout_view, name='logout'),
    path('add_book/', views.add_book, name='add_book'),
    path('view_books/', views.view_books, name='view_books'),
    path('issue_book/', views.issue_book, name='issue_book'),
    path('view_issued_books/', views.view_issued_books, name='view_issued_books'),
     path('view_students/', views.view_students, name='view_students'),

]
