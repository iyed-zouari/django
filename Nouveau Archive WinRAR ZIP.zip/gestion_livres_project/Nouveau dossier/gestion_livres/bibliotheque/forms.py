from django import forms
from .models import Book, IssuedBook, Student

# Formulaire pour ajouter un livre
class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'genre', 'publication_date']

# Formulaire pour emprunter un livre
class IssueBookForm(forms.Form):
    book = forms.ModelChoiceField(queryset=Book.objects.filter(available=True))  # or the correct field
    student = forms.ModelChoiceField(queryset=Student.objects.all())