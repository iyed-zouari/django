from django.db import models
from django.contrib.auth.models import User
from datetime import date



class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    genre = models.CharField(max_length=50)
    publication_date = models.DateField()
    available = models.BooleanField(default=True)

    def __str__(self):
        return self.title

class Borrow(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    borrow_date = models.DateField(auto_now_add=True)
    return_date = models.DateField()  # Date prévue pour le retour
    actual_return_date = models.DateField(null=True, blank=True)  # Date réelle
    overdue = models.BooleanField(default=False)  # Indique si l'emprunt est en retard

    def __str__(self):
        return f'{self.user.username} a emprunté {self.book.title}'

    def is_overdue(self):
        if not self.actual_return_date:
            return date.today() > self.return_date
        return self.actual_return_date > self.return_date

# Use string-based reference to avoid circular imports
class IssuedBook(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    student = models.ForeignKey('Student', on_delete=models.CASCADE)  # Use 'Student' as a string
    issued_date = models.DateField()
    due_date = models.DateField()

class Student(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    enrollment_date = models.DateField()
    # Add other fields as needed

    def __str__(self):
        return f'{self.first_name} {self.last_name}'
